import java.awt.Dimension;
//import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
public class Confirmation {
   public static void main(String[] args) {
      //ImageIcon icon = new ImageIcon("E −ew.PNG");
      JPanel panel = new JPanel();
      panel.setSize(new Dimension(400, 100));
      panel.setLayout(null);
      JLabel label1 = new JLabel("You seat is confirmed");
      label1.setVerticalAlignment(SwingConstants.BOTTOM);
      label1.setBounds(20, 20, 200, 30);
      label1.setHorizontalAlignment(SwingConstants.CENTER);
      panel.add(label1);
      JLabel label2 = new JLabel("Press yes for generating fee receipt");
      label2.setVerticalAlignment(SwingConstants.TOP);
      label2.setHorizontalAlignment(SwingConstants.CENTER);
      label2.setBounds(20, 80, 300, 20);
      panel.add(label2);
      UIManager.put("OptionPane.minimumSize", new Dimension(500, 200));
      int res = JOptionPane.showConfirmDialog(null, panel, "File", JOptionPane.YES_NO_CANCEL_OPTION);
     // JOptionPane.PLAIN_MESSAGE, icon);
      if(res == 0) {
          FeeReceipt.main(new String[1]);
      } else if (res == 1) {
          university uni=new university();
        uni.setVisible(true);
      } //else {
          //panel1.dispose();
         //System.out.println("Pressed CANCEL");
      //}
   }
}