import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Login1 extends JFrame implements ActionListener {

    JLabel l1, l2, l3;   //label for email and password

    JTextField tf1; // email field

    JButton btn1,btn2; // login button

    JPasswordField p1; // password field

    File f = new File("C:\\Files");   //file path
    int ln;
    void createFolder() {
        if (!f.exists()) {
            f.mkdirs();
        }
    }
    //check file is exist or not
    void readFile() {
        try {
            FileReader fr = new FileReader(f + "\\logins.txt");
        } catch (FileNotFoundException ex) {
            try {
                FileWriter fw = new FileWriter(f + "\\logins.txt");
            } catch (IOException ex1) {
            }
        }

    }
    // login logic 
    void logic(String usr, String pswd) {
        try {
            RandomAccessFile raf = new RandomAccessFile(f + "\\logins.txt", "rw");
            for (int i = 0; i < ln; i += 7) {

                String forUser = raf.readLine().substring(6);
                String forPswd = raf.readLine().substring(9);
                if (usr.equals(forUser) & pswd.equals(forPswd)) {
                    JOptionPane.showMessageDialog(null, "Login Successfully!!");
                    System.out.println("file exists!");
                    university uni=new university();
                    uni.setVisible(true);
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect username/password");
                    break;
                }
            }
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }

    }
    void countLines() {
        try {
            ln = 0;
            RandomAccessFile raf = new RandomAccessFile(f + "\\logins.txt", "rw");
            for (int i = 0; raf.readLine() != null; i++) {
                ln++;
            }
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }

    }

    Login1() {

        setTitle("Login Form ");

        setVisible(true);

        setSize(800, 800);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        l1 = new JLabel("Login Here");

        l1.setForeground(Color.blue);

        l1.setFont(new Font("Serif", Font.BOLD, 20));

        l2 = new JLabel("Enter Email:");

        l3 = new JLabel("Enter Password:");

        tf1 = new JTextField();

        p1 = new JPasswordField();

        btn1 = new JButton("Submit");

        btn2 = new JButton("New User");


        l1.setBounds(100, 30, 400, 30);

        l2.setBounds(80, 70, 200, 30);

        l3.setBounds(80, 110, 200, 30);

        tf1.setBounds(300, 70, 200, 30);

        p1.setBounds(300, 110, 200, 30);

        btn1.setBounds(150, 160, 100, 30);

        btn2.setBounds(150,200,100,30);

        add(l1);

        add(l2);

        add(tf1);

        add(l3);

        add(p1);

        add(btn1);

        add(btn2);

        btn1.addActionListener(this);

        btn2.addActionListener(this);

    }

    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==btn1)
         {  new university().setVisible(true);
            dispose();}
        else if(e.getSource()==btn2)
           { new SignUp().setVisible(true);
            dispose();}

    }

    public void showData() {

        JFrame f1 = new JFrame();

        JLabel l, l0;

        String str1 = tf1.getText();

        char[] p = p1.getPassword();

        String str2 = new String(p);

        try {

            createFolder();
            //insert();
            readFile();
            countLines();
            logic(str1, str2);

        } catch (Exception ex) {

            System.out.println(ex);

        }
    }
    public static void main(String arr[]) {
        
        new Login1();

    }

}