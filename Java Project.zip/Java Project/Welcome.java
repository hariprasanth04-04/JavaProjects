import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 
public class Welcome {
   private JFrame mainFrame;
   private JLabel headerLabel;
   private JLabel statusLabel;
   private JPanel controlPanel;

   public Welcome(){
      prepareGUI();
   }
   public static void main(String[] args){
       
      Welcome  wel = new Welcome();      
      wel.showButtonDemo();
   }
   private void prepareGUI(){
      mainFrame = new JFrame("Java Swing Examples");
      mainFrame.setSize(400,300);
      mainFrame.setLayout(new GridLayout(3, 1));
      
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
         }        
      });    
      headerLabel = new JLabel("", JLabel.CENTER);        
      statusLabel = new JLabel("",JLabel.CENTER);    
      statusLabel.setSize(350,100);

      controlPanel = new JPanel();
      controlPanel.setLayout(new FlowLayout());

      mainFrame.add(headerLabel);
      mainFrame.add(controlPanel);
      mainFrame.add(statusLabel);
      mainFrame.setVisible(true);  
   }
   private void showButtonDemo(){
      headerLabel.setText("Welcome Login for search University you want");

      JButton lButton = new JButton("Login");
      JButton cancelButton = new JButton("Cancel");
      cancelButton.setHorizontalTextPosition(SwingConstants.LEFT);  

      lButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            new Login1().setVisible(true);
            mainFrame.dispose();
         }
      });

      cancelButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            mainFrame.dispose();
            //statusLabel.setText("Cancel Button clicked.");
         }

      });
      controlPanel.add(lButton);
      controlPanel.add(cancelButton);       
      mainFrame.setVisible(true);  
   }
}